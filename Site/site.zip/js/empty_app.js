var app = angular.module("empty_app", []); 
app.controller("ctrl", function($scope) {
});