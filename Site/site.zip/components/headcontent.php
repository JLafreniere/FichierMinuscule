  
  <!--Import Google Icon Font-->
  <link rel="stylesheet" href="https://cdn.rawgit.com/chingyawhao/materialize-clockpicker/master/dist/css/materialize.clockpicker.css">
  <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
  <link type="text/css" rel="stylesheet" href="css/materialize.css" media="screen,projection">
  <link type="text/css" rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.1.0/fullcalendar.min.css">
  <link type="text/css" rel="stylesheet" href="css/sc-date-time.css">
  

  

  <link rel="icon" href="http://i.imgur.com/Kgx7Ak4.png">
  <!--Let browser know website is optimized for mobile-->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <?php
  include 'php_scripts/queryfunctions.php';
  include_once 'php_scripts/connexion_bd.php';
  include_once 'php_scripts/formater_champ.php';
  ?>
    <link type="text/css" rel="stylesheet" href="css/style.css">
